var searchData=
[
  ['lower_5flevel_5fdevices_5fcount_0',['lower_level_devices_count',['../struct_header3.html#ae715600ccbaae406b17199f85d8074de',1,'Header3']]]
];
