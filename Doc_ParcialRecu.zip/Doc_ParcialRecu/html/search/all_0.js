var searchData=
[
  ['countdevices_0',['countDevices',['../main_8cpp.html#a3e938d819f9dabf76e283ef48aa3b837',1,'main.cpp']]]
];
