var searchData=
[
  ['device_5ftype_5fnh_0',['device_type_NH',['../struct_header2.html#a01d458c8ffd2488bad0df24df444e877',1,'Header2']]],
  ['device_5ftype_5fnl_1',['device_type_NL',['../struct_header2.html#a466c5d8cee9d1bfa13c1157c3fe3f003',1,'Header2']]],
  ['device_5ftypes_2',['device_types',['../main_8cpp.html#a4cff22bd02fe752c6fab544ebd616c51',1,'main.cpp']]]
];
