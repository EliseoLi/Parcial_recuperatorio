var searchData=
[
  ['id_0',['ID',['../struct_header3.html#a8aca277fb3c5caaa551a7bbeddf7c4a6',1,'Header3']]],
  ['info_1',['info',['../struct_header2.html#aa76a614cd999d383309501acfd8b5f62',1,'Header2']]]
];
